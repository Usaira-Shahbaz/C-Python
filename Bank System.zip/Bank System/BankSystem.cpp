#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Customer {
public:
    string name;
    string address;

    Customer(string n, string addr) : name(n), address(addr) {}
};

class Account {
public:
    string accountType;
    int balance;

    Account(string type, int bal) : accountType(type), balance(bal) {}

    void deposit(int amount) {
        balance += amount;
        cout << "Deposited: " << amount << "\n";
    }

    void withdraw(int amount) {
        if (amount <= balance) {
            balance -= amount;
            cout << "Withdrawn: " << amount << "\n";
        } else {
            cout << "Insufficient balance!\n";
        }
    }

    void displayAccountInfo() {
        cout << "Account Type: " << accountType << "\n";
        cout << "Balance: " << balance << "\n";
    }
};

class Transaction {
public:
    string type;
    int amount;

    Transaction(string t, int a) : type(t), amount(a) {}

    void displayTransaction() const { // Mark this function as const
        cout << "Transaction: " << type << " | Amount: " << amount << "\n";
    }
};


class Bank {
private:
    vector<Customer> customers;
    vector<Account> accounts;
    vector<Transaction> transactions;

public:
    void openAccount() {
        string name, address, accountType;
        int initialDeposit;

        cout << "Enter your full name: ";
        cin.ignore();
        getline(cin, name);
        cout << "Enter your address: ";
        getline(cin, address);
        cout << "What type of account you want to open (saving or current): ";
        cin >> accountType;
        cout << "Enter amount for deposit: ";
        cin >> initialDeposit;

        customers.push_back(Customer(name, address));
        accounts.push_back(Account(accountType, initialDeposit));
        cout << "Account created successfully!\n";
    }

    void depositMoney() {
        int amount;
        cout << "Enter the amount to deposit: ";
        cin >> amount;
        accounts.back().deposit(amount);
        transactions.push_back(Transaction("Deposit", amount));
    }

    void withdrawMoney() {
        int amount;
        cout << "Enter the amount to withdraw: ";
        cin >> amount;
        accounts.back().withdraw(amount);
        transactions.push_back(Transaction("Withdrawal", amount));
    }

    void displayAccount() {
        cout << "Customer Name: " << customers.back().name << "\n";
        cout << "Address: " << customers.back().address << "\n";
        accounts.back().displayAccountInfo();
    }

    void displayTransactions() {
        for (const auto& transaction : transactions) {
            transaction.displayTransaction();
        }
    }

    void transferMoney() {
        int amount;
        cout << "Enter the amount to transfer: ";
        cin >> amount;
        if (amount <= accounts.back().balance) {
            accounts.back().withdraw(amount);
            transactions.push_back(Transaction("Transfer", amount));
            cout << "Transfer successful!\n";
        } else {
            cout << "Insufficient balance for transfer!\n";
        }
    }
};

int main() {
    Bank bank;
    int choice;
    char continueChoice;

    do {
        cout << "1) Open account\n";
        cout << "2) Deposit money\n";
        cout << "3) Withdraw money\n";
        cout << "4) Display account\n";
        cout << "5) Display transactions\n";
        cout << "6) Transfer money\n";
        cout << "7) Exit\n";
        cout << "Select an option: ";
        cin >> choice;

        switch (choice) {
            case 1:
                bank.openAccount();
                break;
            case 2:
                bank.depositMoney();
                break;
            case 3:
                bank.withdrawMoney();
                break;
            case 4:
                bank.displayAccount();
                break;
            case 5:
                bank.displayTransactions();
                break;
            case 6:
                bank.transferMoney();
                break;
            case 7:
                cout << "Exiting...\n";
                return 0;
            default:
                cout << "Invalid option, please try again.\n";
                break;
        }

        cout << "Do you want to continue? (y/n): ";
        cin >> continueChoice;
    } while (continueChoice == 'y' || continueChoice == 'Y');

    return 0;
}
