#include <iostream>
#include <string>
#include <limits>
using namespace std;

struct Course {
    string courseName;
    int credits;
    double grade;
};

void addCourse(Course& course, string name, int credits, double grade) {
    course.courseName = name;
    course.credits = credits;
    course.grade = grade;
}

double calculateCGPA(Course courses[], int numCourses) {
    double totalGradePoints = 0.0;
    int totalCredits = 0;

    for (int i = 0; i < numCourses; ++i) {
        totalGradePoints += courses[i].grade * courses[i].credits;
        totalCredits += courses[i].credits;
    }

    if (totalCredits == 0) return 0.0;

    return totalGradePoints / totalCredits;
}

void displayResults(string studentName, Course courses[], int numCourses) {
    cout << "Student: " << studentName << endl;
    cout << "Course Grades: " << endl;

    for (int i = 0; i < numCourses; ++i) {
        cout << "Course: " << courses[i].courseName
             << ", Credits: " << courses[i].credits
             << ", Grade: " << courses[i].grade << endl;
    }

    cout << "CGPA: " << calculateCGPA(courses, numCourses) << endl;
}

int main() {
    string studentName;
    cout << "Enter student name: ";
    getline(cin, studentName);

    int numCourses;
    cout << "Enter number of courses: ";
    while (!(cin >> numCourses) || numCourses <= 0) {
        cout << "Please enter a valid positive number for courses: ";
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }

    cin.ignore();

    Course* courses = new Course[numCourses];

    for (int i = 0; i < numCourses; ++i) {
        string courseName;
        int credits;
        double grade;

        cout << "Enter course name: ";
        getline(cin, courseName);

        cout << "Enter course credits: ";
        while (!(cin >> credits) || credits <= 0) {
            cout << "Please enter a valid positive number for credits: ";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }

        cout << "Enter course grade (0 to 4 scale): ";
        while (!(cin >> grade) || grade < 0.0 || grade > 4.0) {
            cout << "Please enter a valid grade (0 to 4 scale): ";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }

        cin.ignore();

        addCourse(courses[i], courseName, credits, grade);
    }

    displayResults(studentName, courses, numCourses);

    delete[] courses;

    return 0;
}
